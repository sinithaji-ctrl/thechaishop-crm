from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3, os, re, smtplib
from email.message import EmailMessage
from functools import wraps
from datetime import datetime, date
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "crm.db")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "thechaishop-development-secret-change-me")


def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'Employee'
    );
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        dob TEXT,
        gender TEXT,
        address TEXT,
        customer_type TEXT NOT NULL DEFAULT 'Walk-In Order',
        employer TEXT,
        pan TEXT,
        aadhaar_last4 TEXT,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        category TEXT,
        price REAL NOT NULL DEFAULT 0,
        stock INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        subtotal REAL NOT NULL,
        discount REAL NOT NULL DEFAULT 0,
        total REAL NOT NULL,
        payment TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );
    """)

    # Lightweight migrations for older local databases.
    cols = {r[1] for r in con.execute("PRAGMA table_info(customers)").fetchall()}
    for col, definition in [("employer", "TEXT"), ("pan", "TEXT"), ("aadhaar_last4", "TEXT")]:
        if col not in cols:
            con.execute(f"ALTER TABLE customers ADD COLUMN {col} {definition}")
    con.execute("UPDATE customers SET customer_type='Walk-In Order' WHERE customer_type='Walk-In'")

    admin = con.execute("SELECT id FROM users WHERE username='admin'").fetchone()
    if not admin:
        con.execute(
            "INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
            ("admin", generate_password_hash("admin123"), "Admin")
        )

    if con.execute("SELECT COUNT(*) n FROM products").fetchone()["n"] == 0:
        con.executemany(
            "INSERT INTO products(name,category,price,stock) VALUES(?,?,?,?)",
            [
                ("Masala Chai", "Classic Chai", 80, 50),
                ("Ginger Chai", "Classic Chai", 90, 45),
                ("Cardamom Chai", "Classic Chai", 95, 32),
                ("Green Tea", "Tea", 100, 30),
                ("Saffron Milk Tea", "Premium Tea", 140, 18),
                ("Assorted Chai Gift Box", "Gifts", 350, 12),
            ]
        )
    # Presentation-ready demo records are inserted only into an empty customer/order database.
    # They can be removed later from the CRM without affecting the application.
    if con.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"] == 0:
        demo_customers = [
            ("Ananya Ravi", "9876543210", "ananya@example.com", "1998-10-08", "Female", "12 MG Road, Chennai", "Walk-In Order", "Ravi Traders", "ABCDE1234F", "4821"),
            ("Arjun Kumar", "9123456780", "arjun@example.com", "1995-11-21", "Male", "8 Anna Nagar, Chennai", "Online Order", "Kumar & Co", "BCDEF2345G", "6157"),
            ("Meera S", "9001122334", "meera@example.com", "2000-10-10", "Female", "24 Temple Street, Madurai", "Walk-In Order", "Sundar Stores", "CDEFG3456H", "9034"),
            ("Rahul Dev", "9988776655", "rahul@example.com", "1994-12-02", "Male", "5 Market Road, Coimbatore", "Enterprise Account", "Dev Enterprises", "DEFGH4567J", "2219"),
            ("Nila Priya", "9345678123", "nila@example.com", "1999-01-17", "Female", "17 Lake View, Salem", "Online Order", "Priya Textiles", "EFGHI5678K", "7406"),
            ("Vikram Shah", "9789012345", "vikram@example.com", "1992-03-26", "Male", "31 Park Avenue, Bengaluru", "Enterprise Account", "Shah Foods", "FGHIJ6789L", "1185"),
        ]
        for c in demo_customers:
            con.execute("""INSERT INTO customers(name,phone,email,dob,gender,address,customer_type,employer,pan,aadhaar_last4,created_at)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (*c, datetime.now().isoformat(timespec='seconds')))
        cust_ids = [r[0] for r in con.execute("SELECT id FROM customers ORDER BY id").fetchall()]
        prods = [r for r in con.execute("SELECT id,price FROM products ORDER BY id").fetchall()]
        demo_orders = [(cust_ids[0],prods[0][0],3,0,'UPI'),(cust_ids[1],prods[4][0],2,20,'Card'),(cust_ids[2],prods[1][0],4,0,'Cash'),(cust_ids[3],prods[5][0],2,30,'Bank Transfer'),(cust_ids[4],prods[2][0],3,10,'UPI'),(cust_ids[5],prods[0][0],5,25,'Card'),(cust_ids[0],prods[3][0],2,0,'Cash'),(cust_ids[2],prods[4][0],1,0,'UPI')]
        for cid,pid,qty,discount,payment in demo_orders:
            price=con.execute("SELECT price FROM products WHERE id=?",(pid,)).fetchone()[0]
            subtotal=price*qty; discount=min(discount,subtotal); total=subtotal-discount
            con.execute("INSERT INTO orders(customer_id,product_id,quantity,subtotal,discount,total,payment,created_at) VALUES(?,?,?,?,?,?,?,?)", (cid,pid,qty,subtotal,discount,total,payment,datetime.now().isoformat(timespec='seconds')))
            con.execute("UPDATE products SET stock=MAX(stock-?,0) WHERE id=?",(qty,pid))

    con.commit()
    con.close()


init_db()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "uid" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "Admin":
            flash("Admin access is required for this action.", "error")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped


@app.context_processor
def inject_globals():
    return {"now": datetime.now()}


@app.route("/", methods=["GET", "POST"])
def login():
    if session.get("uid"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        con = db()
        user = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        con.close()
        if user and check_password_hash(user["password_hash"], password):
            session.update(uid=user["id"], username=user["username"], role=user["role"])
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    con = db()
    today = date.today().isoformat()
    stats = {
        "customers": con.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"],
        "orders": con.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"],
        "sales": con.execute("SELECT COALESCE(SUM(total),0) n FROM orders").fetchone()["n"],
        "today_sales": con.execute("SELECT COALESCE(SUM(total),0) n FROM orders WHERE substr(created_at,1,10)=?", (today,)).fetchone()["n"],
        "low": con.execute("SELECT COUNT(*) n FROM products WHERE active=1 AND stock<10").fetchone()["n"],
    }
    recent = con.execute("""
        SELECT o.*, c.name customer, p.name product
        FROM orders o JOIN customers c ON c.id=o.customer_id JOIN products p ON p.id=o.product_id
        ORDER BY o.id DESC LIMIT 7
    """).fetchall()
    top = con.execute("""
        SELECT p.name, SUM(o.quantity) qty, SUM(o.total) sales
        FROM orders o JOIN products p ON p.id=o.product_id
        GROUP BY p.id ORDER BY sales DESC LIMIT 5
    """).fetchall()
    low_stock = con.execute("SELECT * FROM products WHERE active=1 AND stock<10 ORDER BY stock ASC LIMIT 5").fetchall()
    birthdays = con.execute("""
        SELECT * FROM customers WHERE dob IS NOT NULL AND dob != ''
        ORDER BY substr(dob,6,5) LIMIT 5
    """).fetchall()
    con.close()
    return render_template("dashboard.html", stats=stats, recent=recent, top=top, low_stock=low_stock, birthdays=birthdays)


@app.route("/customers", methods=["GET", "POST"])
@login_required
def customers():
    con = db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Customer name is required.", "error")
        else:
            phone = request.form.get("phone", "").strip()
            if phone and not re.fullmatch(r"[6-9]\d{9}", phone):
                flash("Enter a valid 10-digit Indian mobile number.", "error")
            else:
                con.execute("""
                    INSERT INTO customers(name,phone,email,dob,gender,address,customer_type,employer,pan,aadhaar_last4,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """, (name, phone, request.form.get("email", "").strip(), request.form.get("dob", ""),
                      request.form.get("gender", ""), request.form.get("address", "").strip(),
                      request.form.get("customer_type", "Walk-In Order"), request.form.get("employer", "").strip(),
                      request.form.get("pan", "").strip().upper(), request.form.get("aadhaar_last4", "").strip(),
                      datetime.now().isoformat(timespec="seconds")))
                con.commit()
                flash("Customer added successfully.", "success")
    q = request.args.get("q", "").strip()
    rows = con.execute("""
        SELECT * FROM customers
        WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?
        ORDER BY id DESC
    """, (f"%{q}%", f"%{q}%", f"%{q}%")).fetchall()
    con.close()
    return render_template("customers.html", customers=rows, q=q)


@app.route("/customers/<int:id>/edit", methods=["GET", "POST"])
@login_required
def customer_edit(id):
    con = db()
    customer = con.execute("SELECT * FROM customers WHERE id=?", (id,)).fetchone()
    if not customer:
        con.close(); flash("Customer not found.", "error"); return redirect(url_for("customers"))
    if request.method == "POST":
        phone=request.form.get("phone", "").strip()
        if phone and not re.fullmatch(r"[6-9]\d{9}", phone):
            flash("Enter a valid 10-digit Indian mobile number.", "error")
        else:
            con.execute("""UPDATE customers SET name=?,phone=?,email=?,dob=?,gender=?,address=?,customer_type=?,employer=?,pan=?,aadhaar_last4=? WHERE id=?""",
                         (request.form.get("name","").strip(),phone,request.form.get("email","").strip(),request.form.get("dob",""),request.form.get("gender",""),request.form.get("address","").strip(),request.form.get("customer_type","Walk-In Order"),request.form.get("employer","").strip(),request.form.get("pan","").strip().upper(),request.form.get("aadhaar_last4","").strip(),id))
            con.commit(); con.close(); flash("Customer updated successfully.","success"); return redirect(url_for("customers"))
    con.close(); return render_template("customer_edit.html", customer=customer)


@app.route("/customers/<int:id>/delete", methods=["POST"])
@login_required
def customer_delete(id):
    con = db()
    used = con.execute("SELECT COUNT(*) n FROM orders WHERE customer_id=?", (id,)).fetchone()["n"]
    if used:
        flash("This customer has orders and cannot be deleted. Keep the record for CRM history.", "error")
    else:
        con.execute("DELETE FROM customers WHERE id=?", (id,)); con.commit(); flash("Customer removed.", "success")
    con.close()
    return redirect(url_for("customers"))


@app.route("/orders", methods=["GET", "POST"])
@login_required
def orders():
    con = db()
    if request.method == "POST":
        try:
            cid = int(request.form["customer_id"]); pid = int(request.form["product_id"])
            qty = max(1, int(request.form["quantity"])); discount = max(0.0, float(request.form.get("discount", 0) or 0))
        except (ValueError, KeyError):
            flash("Please enter valid order details.", "error"); return redirect(url_for("orders"))
        payment = request.form.get("payment", "Cash")
        product = con.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()
        if not product:
            flash("Product not found.", "error")
        elif product["stock"] < qty:
            flash(f"Only {product['stock']} units of {product['name']} are available.", "error")
        else:
            subtotal = product["price"] * qty
            discount = min(discount, subtotal)
            total = subtotal - discount
            con.execute("""
                INSERT INTO orders(customer_id,product_id,quantity,subtotal,discount,total,payment,created_at)
                VALUES(?,?,?,?,?,?,?,?)
            """, (cid,pid,qty,subtotal,discount,total,payment,datetime.now().isoformat(timespec="seconds")))
            con.execute("UPDATE products SET stock=stock-? WHERE id=?", (qty,pid))
            con.commit()
            flash(f"Order saved successfully • Total ₹{total:,.2f}", "success")
    rows = con.execute("""
        SELECT o.*,c.name customer,p.name product
        FROM orders o JOIN customers c ON c.id=o.customer_id JOIN products p ON p.id=o.product_id
        ORDER BY o.id DESC
    """).fetchall()
    customers_list = con.execute("SELECT id,name FROM customers ORDER BY name").fetchall()
    products_list = con.execute("SELECT * FROM products WHERE active=1 ORDER BY name").fetchall()
    con.close()
    return render_template("orders.html", orders=rows, customers=customers_list, products=products_list)


@app.route("/products", methods=["GET", "POST"])
@login_required
@admin_required
def products():
    con = db()
    if request.method == "POST":
        try:
            name = request.form["name"].strip(); category = request.form.get("category", "Tea").strip()
            price = float(request.form["price"]); stock = int(request.form["stock"])
            if not name or price < 0 or stock < 0: raise ValueError
            con.execute("INSERT OR REPLACE INTO products(name,category,price,stock,active) VALUES(?,?,?,?,1)", (name,category,price,stock))
            con.commit(); flash("Menu item saved successfully.", "success")
        except (ValueError, KeyError):
            flash("Please enter valid product details.", "error")
    rows = con.execute("SELECT * FROM products ORDER BY active DESC, name").fetchall(); con.close()
    return render_template("products.html", products=rows)


@app.route("/products/<int:id>/delete", methods=["POST"])
@login_required
@admin_required
def product_delete(id):
    con = db(); used = con.execute("SELECT COUNT(*) n FROM orders WHERE product_id=?", (id,)).fetchone()["n"]
    if used:
        con.execute("UPDATE products SET active=0 WHERE id=?", (id,)); flash("Product archived because it has sales history.", "success")
    else:
        con.execute("DELETE FROM products WHERE id=?", (id,)); flash("Product removed.", "success")
    con.commit(); con.close(); return redirect(url_for("products"))


@app.route("/birthday-offers")
@login_required
def birthday_offers():
    con=db()
    rows=con.execute("""SELECT * FROM customers WHERE dob IS NOT NULL AND dob!='' ORDER BY substr(dob,6,5)""").fetchall()
    con.close()
    return render_template("birthday.html", customers=rows)


@app.route("/reports")
@login_required
def reports():
    con = db()
    daily = con.execute("SELECT substr(created_at,1,10) day, SUM(total) sales, COUNT(*) orders FROM orders GROUP BY day ORDER BY day DESC LIMIT 14").fetchall()
    top = con.execute("SELECT p.name,SUM(o.quantity) qty,SUM(o.total) sales FROM orders o JOIN products p ON p.id=o.product_id GROUP BY p.id ORDER BY sales DESC LIMIT 10").fetchall()
    totals = {
        "revenue": con.execute("SELECT COALESCE(SUM(total),0) n FROM orders").fetchone()["n"],
        "discount": con.execute("SELECT COALESCE(SUM(discount),0) n FROM orders").fetchone()["n"],
        "orders": con.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"],
        "avg": con.execute("SELECT COALESCE(AVG(total),0) n FROM orders").fetchone()["n"],
    }
    con.close(); return render_template("reports.html", daily=daily, top=top, totals=totals)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
