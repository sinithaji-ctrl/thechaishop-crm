# TheChaiShop&Co CRM — Final Tea House Edition

A real local **Flask + SQLite** CRM application implementing the core workflow described in the TheChaiShop&Co CRM project: customer management, online/walk-in/enterprise account types, orders and billing, inventory, birthday offers, and reports/dashboard analytics.

## Final design
- Custom TheChaiShop tea-cup logo
- Tea-leaf/pattern background
- Chai-brown + warm cream visual system
- Cormorant Garamond display typography with clean Inter UI text
- Premium tea-house dashboard with live CRM metrics, latest orders, popular menu, birthday care and stock watch
- Responsive layout

## Working features
- Admin login and session-based access
- Customer create, search, edit and safe-delete
- Customer type: Walk-In Order / Online Order / Enterprise Account
- Employer/company, birthday, contact and profile fields
- Indian mobile-number validation
- Orders with quantity, automatic subtotal/total, discount and payment mode
- Stock deduction after successful orders
- Admin menu/inventory management
- Birthday offer queue using the project's 50% / HBDAY50 concept
- Reports and sales analytics
- SQLite database created automatically on first run

## Run on Windows
1. Extract this ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal.
4. Run `pip install -r requirements.txt`
5. Run `python app.py`
6. Open `http://127.0.0.1:5000`

Demo login: **admin / admin123**

## Important project boundary
The source project/report describes Salesforce Lightning, Salesforce Cloud, Salesforce Flows and automated birthday email alerts. This application is a separate Flask implementation of the same CRM workflow for demonstration and local operation; it is not a Salesforce deployment. Actual email delivery and public internet deployment require additional production configuration.

## Safety
Do not enter real Aadhaar/PAN data into a student/demo installation. Production identity-data handling requires appropriate security, privacy and compliance controls.
